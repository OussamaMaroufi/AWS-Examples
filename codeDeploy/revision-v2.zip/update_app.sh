sudo rm /var/www/html/index.html
sudo cp /revision/index.html var/www/html/index.html